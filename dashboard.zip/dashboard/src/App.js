import React from 'react';
import Dashboard from "./component/dashboard/dashboard";
import './App.css'

function App() {
  return(
    <>
    <Dashboard></Dashboard>
    </>
  )
}
export default App;
